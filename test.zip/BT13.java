package test;
import java.util.Scanner;
import java.util.Scanner;

public class BT13 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		 System.out.print("nhap vao so phan tu cua mang: ");
	        int n = sc.nextInt();
	        int tong=0;
	        int[] mang = new int[n];
	        System.out.println("nhap cac phan tu cua mang :");
	        for (int i = 0; i < n; i++) {
	            System.out.print("phan tu thu " + (i + 1) + ": ");
	            mang[i] = sc.nextInt();
	        }
	        
	        for(int i=1;i<=n;i++){
	        	tong+=i;
	        }
	        
	        System.out.print("tong cua mang la: "+tong);
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	        
	}

}
