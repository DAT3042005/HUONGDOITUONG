package test;
import java.util.Scanner;
import java.util.Scanner;

public class BT12 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		 System.out.print("nhap vao so phan tu cua mang: ");
	        int n = sc.nextInt();
	        
	        int[] mang = new int[n];
	        System.out.println("nhap cac phan tu cua mang :");
	        for (int i = 0; i < n; i++) {
	            System.out.print("phan tu thu " + (i + 1) + ": ");
	            mang[i] = sc.nextInt();
	        }
	        boolean hasPositive = false;
	        for (int i = 0; i < n; i++) {
	            if (mang[i] > 0) {
	                hasPositive = true;
	                break;
	            }
	        }
	        
	       
	        if (hasPositive) {
	            System.out.println("mang chua it nhat mot so duong ");
	        } else {
	            System.out.println("mang ko chua so duong ");
	        }
	        
	        
	        
	}

}
