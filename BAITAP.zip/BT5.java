package BAITAP;
import java.util.Scanner;
public class BT5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("nhap vao a");
		int a = sc.nextInt();
		System.out.println("nhap vao b");
		int b = sc.nextInt();
		
		int a1=Math.abs(a);
		int b1=Math.abs(b);
		if(a1==0 || b1==0){
			System.out.println("ko xu ly truong hop =0");
		}else{
			while(a1!=b1){
				if(a1>b1)
					a1-=b1;
				else
					b1-=a1;
			}
			System.out.println("Uoc cua a ="+a+"b="+b+" la"+a1);
		}
		
		
		
		// TODO Auto-generated method stub

	}

}
