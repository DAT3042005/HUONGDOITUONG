package BAITAP;
import java.util.Scanner; 
public class bt6 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n;
		System.out.println("nhap vao so nguyen duong n: ");
		n = sc.nextInt();
		if(n<=1){
			System.out.println("day khong phai la so nguyen to ");
			return;
		}
		
		int i=2;
		boolean co=false;
		while(i*i<=n){
			if(n%i==0)
			{
				co=true;
				break;
			}
			i++;
		}
	       if(co)
	       {
	    	   System.out.println("day ko phai so nguyen to");
	       }else
	       {
	    	   System.out.println("day la so nguyen to");
	       }
	  
			
		}
		
		
		// TODO Auto-generated method stub

	}


