package BAITAP;
import java.util.Scanner; 
public class BT8 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

	for(int i=0;i<=9;i++)
	{
		System.out.println("bang cuu chuong "+i);
		for(int j=1;j<=10;j++)
		{   int tong=i*j;
			System.out.println(i+" x "+j+"="+tong);
		}
	}	
		// TODO Auto-generated method stub
	}
}
