package BAITAP;

import java.util.Scanner;

public class BT10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	       int n; 
	       int tong=0;
			do{
			System.out.println("nhap vao so nguyen duong n");
	       n = sc.nextInt();
	       }while(n<0); 
		   for( int i=0;i<=n;i++){
			
			  tong=tong+i*i; 
		   }
		   System.out.println("tong cua day so la: "+tong);
			// TODO Auto-generated method stub

		}
		// TODO Auto-generated method stub
	}


